<?php

return [
    'db' => [
        'host' => 'localhost',
        'port' => '6379',
    ]
];
