<?php

namespace DTO;

/**
 * The Data Transfer Object for User.
 * It stores the mandatory data for a particular use case - for example ignoring the groups,
 * and ensuring easy serialization.
 */

class UserDTO
{
    /**
     * In more complex implementations, the population of the DTO can be the responsibilty
     * of an Assembler object, which would also break any dependency between User and UserDTO.
     */
    public function __construct(User $user)
    {
        $this->_name = $user->getName();
        $this->_role = $user->getRole();
    }

    public function getName()
    {
        return $this->_name;
    }

    public function getRole()
    {
        return $this->_role;
    }
    
    // there are no setters because this use cases does not require modification of data
    // however, in general DTOs do not need to be immutable.
}
