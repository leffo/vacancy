<?php

use DTO;

// client code
$user = new User();
$user->setName('Giorgio');
$user->setRole('Author');
$user->addGroup(new Group('Authors'));
$user->addGroup(new Group('Editors'));

// many more groups
$dto = new UserDTO($user);

// this value is what will be stored in the session, or in a cache...
var_dump(serialize($dto));
