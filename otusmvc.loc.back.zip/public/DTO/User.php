<?php

namespace DTO;

class User
{
    private string $_name;
    private string $_role;
    private array $_groups = [];
 
    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->_name;
    }
 
    public function setName($name)
    {
        $this->_name = $name;
    }

    public function getRole(): string
    {
        return $this->_role;
    }
 
    public function setRole($role)
    {
        $this->_role = $role;
    }
 
    public function addGroup(Group $group)
    {
        $this->_groups[] = $group;
    }
 
    public function getGroups()
    {
        return $this->_groups;
    }
}
