<?php

namespace DTO;

/**
 * Another Domain Model class.
 */
class Group
{
    private string $_name;

    public function __construct($name)
    {
        $this->setName($name);
    }
    
    public function getName(): string
    {
        return $this->_name;
    }

    public function setName(string $name)
    {
        $this->_name = $name;
    }
}
