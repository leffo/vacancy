<?php


namespace AYakovlev\Exception;


class DbException extends \Exception
{

}