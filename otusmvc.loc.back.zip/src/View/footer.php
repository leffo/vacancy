</div>
<div class="footer">All rights reserved (c)2020 Refactoring</div>
</body>
</html>