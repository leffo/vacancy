<?php
/**
 * @var array $data - ошибка приложения.
 */
?>
<?php include 'header.php'; ?>
<h3>Хьюстон, у нас проблема!</h3>
<?=$data[0] ?>
<?php include 'footer.php'; ?>
