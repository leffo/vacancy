<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Refactoring is a Right Way to enhanced Application!</title>
    <link rel="stylesheet" href="/styles.css">
</head>
<body>

<div class="layout">
        <div class="header">
            Refactor this!
        </div>
