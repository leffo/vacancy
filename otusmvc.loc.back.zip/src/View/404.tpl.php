<?php
/**
 *  @var array $data - массив входящих переменных
 */
?>
<?php include 'header.php'; ?>
<h3>Articles #<?=$data[0] ?> not found</h3>
<?php include 'footer.php'; ?>

