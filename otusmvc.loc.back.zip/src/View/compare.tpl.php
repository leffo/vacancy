<?php
/**
 * @var array $data - входные данные.
 */
?>
<?php include 'header.php'; ?>
<h3>Best event!</h3>
<pre><?php print_r($data[0]) ?></pre>
<pre><?php print_r($data[1]) ?></pre>
<?php include 'footer.php'; ?>
